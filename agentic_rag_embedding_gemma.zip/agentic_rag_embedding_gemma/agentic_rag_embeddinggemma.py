import streamlit as st
import lancedb
import pandas as pd
import mlflow
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
try:
    from docling.document_converter import DocumentConverter
    DOCLING_AVAILABLE = True
except ImportError:
    DOCLING_AVAILABLE = False
    import PyPDF2
from phi.agent import Agent
from phi.embedder.ollama import OllamaEmbedder
from phi.knowledge.pdf import PDFUrlKnowledgeBase, PDFKnowledgeBase
from phi.model.ollama import Ollama

# Page configuration
st.set_page_config(
    page_title="Agentic RAG with Google's EmbeddingGemma",
    page_icon="🔥",
    layout="wide"
)

# MLflow setup
mlflow.set_tracking_uri("./mlruns")
mlflow.set_experiment("RAG_Evaluation")

# Evaluation functions for 90% accuracy
def evaluate_response_quality(query, response, ground_truth=None):
    metrics = {}
    metrics['response_length'] = len(response.split())
    metrics['char_count'] = len(response)
    metrics['has_content'] = len(response.strip()) > 10
    
    # Content accuracy metrics
    query_words = set(query.lower().split())
    response_words = set(response.lower().split())
    metrics['keyword_overlap'] = len(query_words.intersection(response_words)) / len(query_words) if query_words else 0
    
    # Content quality indicators
    metrics['has_structure'] = any(marker in response for marker in ['•', '-', '1.', '2.', '#', '**'])
    metrics['completeness'] = min(1.0, metrics['response_length'] / 100)
    metrics['relevance_score'] = metrics['keyword_overlap']
    
    # Content accuracy score (0-1)
    accuracy_score = 0
    if metrics['has_content']: accuracy_score += 0.2
    if metrics['response_length'] > 50: accuracy_score += 0.2
    if metrics['keyword_overlap'] > 0.3: accuracy_score += 0.3
    if metrics['has_structure']: accuracy_score += 0.15
    if metrics['completeness'] > 0.5: accuracy_score += 0.15
    
    metrics['content_accuracy'] = min(1.0, accuracy_score)
    metrics['overall_score'] = metrics['content_accuracy']
    
    return metrics

def log_evaluation_metrics(query, response, metrics):
    if st.session_state.get('mlflow_enabled', True):
        try:
            import time
            run_name = f"query_{int(time.time())}"
            
            with mlflow.start_run(run_name=run_name):
                # Log prompt details
                mlflow.log_param("query", query)
                mlflow.log_param("query_length", len(query))
                mlflow.log_param("response_length", len(response))
                mlflow.log_param("timestamp", time.strftime("%Y-%m-%d %H:%M:%S"))
                
                # Log all accuracy metrics
                for key, value in metrics.items():
                    if isinstance(value, (int, float)):
                        mlflow.log_metric(key, float(value))
                
                # Save complete prompt and response as artifacts
                with open("temp_prompt.txt", "w", encoding="utf-8") as f:
                    f.write(query)
                mlflow.log_artifact("temp_prompt.txt", "prompts")
                
                with open("temp_response.txt", "w", encoding="utf-8") as f:
                    f.write(response)
                mlflow.log_artifact("temp_response.txt", "responses")
                
                # Add tags
                mlflow.set_tag("model", "llama3.2")
                mlflow.set_tag("embedder", "embeddinggemma")
                mlflow.set_tag("accuracy_level", "high" if metrics['content_accuracy'] > 0.8 else "medium" if metrics['content_accuracy'] > 0.5 else "low")
                mlflow.set_tag("query_type", "summary" if "summar" in query.lower() else "question")
                
                st.success(f"✅ MLflow Logged: {run_name} - Accuracy: {metrics['content_accuracy']:.2f}")
                
            # Clean up temp files
            import os
            try:
                os.remove("temp_prompt.txt")
                os.remove("temp_response.txt")
            except:
                pass
                
        except Exception as e:
            st.error(f"❌ MLflow logging failed: {str(e)}")
            import traceback
            st.error(traceback.format_exc())

def load_knowledge_base(urls, pdf_paths):
    if not urls and not pdf_paths:
        return None
    
    try:
        # Use fresh database path to avoid version conflicts
        import time
        db_path = f"lance_db_{int(time.time())}"
        db = lancedb.connect(db_path)
        
        import ollama
        
        # Load PDF content with Docling or fallback to PyPDF2
        documents = []
        if pdf_paths:
            for pdf_path in pdf_paths:
                if DOCLING_AVAILABLE:
                    try:
                        # Use Docling for advanced PDF processing
                        converter = DocumentConverter()
                        result = converter.convert(pdf_path)
                        full_text = result.document.export_to_markdown()
                        
                        # Extract images if available
                        image_folder = f"extracted_images/{pdf_path.split('/')[-1]}_images"
                        import os
                        os.makedirs(image_folder, exist_ok=True)
                        
                        if hasattr(result.document, 'pictures') and result.document.pictures:
                            for img_index, picture in enumerate(result.document.pictures):
                                try:
                                    img_path = f"{image_folder}/image_{img_index+1}.png"
                                    if hasattr(picture, 'image') and picture.image:
                                        with open(img_path, 'wb') as f:
                                            f.write(picture.image)
                                except Exception as e:
                                    st.warning(f"Failed to extract image {img_index+1}: {e}")
                    except Exception as e:
                        st.warning(f"Docling failed, using PyPDF2: {e}")
                        # Fallback to PyPDF2
                        with open(pdf_path, 'rb') as file:
                            reader = PyPDF2.PdfReader(file)
                            full_text = ""
                            for page_num, page in enumerate(reader.pages):
                                page_text = page.extract_text()
                                page_text = page_text.replace('\n', ' ').replace('  ', ' ')
                                full_text += f"Page {page_num + 1}: {page_text}\n\n"
                else:
                    # Use PyPDF2 if Docling not available
                    with open(pdf_path, 'rb') as file:
                        reader = PyPDF2.PdfReader(file)
                        full_text = ""
                        for page_num, page in enumerate(reader.pages):
                            page_text = page.extract_text()
                            page_text = page_text.replace('\n', ' ').replace('  ', ' ')
                            full_text += f"Page {page_num + 1}: {page_text}\n\n"
                
                # Split into chunks
                chunks = [full_text[i:i+1000] for i in range(0, len(full_text), 800)]
                for i, chunk in enumerate(chunks):
                    if len(chunk.strip()) > 50:
                        documents.append({"content": chunk, "source": f"{pdf_path}_chunk_{i}"})
        
        # Create table with embeddings
        data = []
        for doc in documents:
            try:
                # Get embedding from ollama
                response = ollama.embeddings(model="embeddinggemma:latest", prompt=doc["content"])
                embedding = response["embedding"]
                data.append({
                    "content": doc["content"],
                    "source": doc["source"],
                    "vector": embedding
                })
            except Exception as e:
                st.warning(f"Failed to embed chunk: {e}")
                continue
        
        if data:
            try:
                table = db.create_table("docs", data, mode="overwrite")
                st.success(f"Created {len(data)} embeddings with {'Docling' if DOCLING_AVAILABLE else 'PyPDF2'}")
                
                # Store table reference and db path for searching
                st.session_state.lance_table = table
                st.session_state.db_path = db_path
            except Exception as e:
                st.error(f"Failed to create table: {e}")
                # Try with a different table name
                try:
                    table = db.create_table(f"docs_{int(time.time())}", data)
                    st.success(f"Created {len(data)} embeddings (alternative table)")
                    st.session_state.lance_table = table
                    st.session_state.db_path = db_path
                except Exception as e2:
                    st.error(f"Failed to create alternative table: {e2}")
        
        # Return simple knowledge base and load it
        if pdf_paths:
            kb = PDFKnowledgeBase(path=pdf_paths[0])
            kb.load()
            return kb
        elif urls:
            kb = PDFUrlKnowledgeBase(urls=urls)
            kb.load()
            return kb
        
        return None
        
        return knowledge_bases[0] if len(knowledge_bases) == 1 else knowledge_bases
    except Exception as e:
        st.error(f"Failed to load knowledge base: {e}")
        return None

# Initialize session state
if 'urls' not in st.session_state:
    st.session_state.urls = []
if 'pdf_files' not in st.session_state:
    st.session_state.pdf_files = []

# Load knowledge base with current files
kb = load_knowledge_base(st.session_state.urls, st.session_state.pdf_files)

# Custom search function for LanceDB
def search_knowledge_base(query: str) -> str:
    if 'lance_table' in st.session_state:
        try:
            import ollama
            
            # For summary queries, get ALL content instead of semantic search
            if any(word in query.lower() for word in ["summar", "overview", "bullet"]):
                # Get all chunks from the document
                all_data = st.session_state.lance_table.to_pandas()
                context = "FULL DOCUMENT CONTENT:\n\n"
                for _, row in all_data.iterrows():
                    context += f"{row['content']}\n\n"
                return context
            else:
                # Cosine similarity search for better results
                response = ollama.embeddings(model="embeddinggemma:latest", prompt=query)
                query_embedding = np.array(response["embedding"]).reshape(1, -1)
                
                # Get all embeddings and calculate cosine similarity
                all_data = st.session_state.lance_table.to_pandas()
                embeddings = np.array([row['vector'] for _, row in all_data.iterrows()])
                
                # Calculate cosine similarities
                similarities = cosine_similarity(query_embedding, embeddings)[0]
                
                # Get top 5 most similar chunks
                top_indices = np.argsort(similarities)[::-1][:5]
                
                context = ""
                for idx in top_indices:
                    if similarities[idx] > 0.3:  # Similarity threshold
                        row = all_data.iloc[idx]
                        context += f"{row['content'][:500]}...\n\n"
                
                return context if context else "No relevant information found."
        except Exception as e:
            return f"Search error: {e}"
    return "No knowledge base available."

# Create agent with custom search
if 'agent' not in st.session_state or st.session_state.get('kb_updated', False):
    from phi.tools import Toolkit
    
    # Create custom toolkit with search function
    search_toolkit = Toolkit()
    search_toolkit.register(search_knowledge_base)
    
    st.session_state.agent = Agent(
        model=Ollama(id="llama3.2:latest"),
        tools=[search_toolkit] if 'lance_table' in st.session_state else [],
        instructions=[
            "Provide executive summary first, then details",
            "Offer multi-granularity summaries (short 3-point, medium 5-point, and full 10-point",
            "Include a “limitations or gaps” line in every summary",
            "Use bullet points (•) for summaries.",
            "Be thorough and detailed in your responses.",
            "If the query is not related to the document, respond with 'No relevant information found.'",
            "Add recommendations or next steps if applicable. ",
            "Allow style variations: critical, optimistic, persuasive, technical, simple.",
            "Allow audience tuning: executive, technical engineer, student.",
            "Allow format tuning: bullets, paragraphs, Q&A",
            "Re-rank should never change facts, only style and framing.",

        ],
        show_tool_calls=False,
        markdown=True,
    )
    st.session_state.kb_updated = False

agent = st.session_state.agent

# Sidebar for adding knowledge sources
with st.sidebar:
    col1, col2, col3 = st.columns(3)
    with col1:
        st.image("google.png")
    with col2:
        st.image("ollama.png")
    with col3:
        st.image("agno.png")
    st.header("🌐 Add Knowledge Sources")
    
    # PDF URL input
    new_url = st.text_input(
        "Add PDF URL",
        placeholder="https://example.com/sample.pdf",
        help="Enter a PDF URL to add to the knowledge base",
    )
    if st.button("➕ Add URL", type="primary"):
        if new_url:
            st.session_state.urls.append(new_url)
            # Mark knowledge base for update
            st.session_state.kb_updated = True
            st.rerun()
        else:
            st.error("Please enter a URL")
    
    st.divider()
    
    # Local PDF file upload
    uploaded_file = st.file_uploader(
        "Upload PDF File",
        type="pdf",
        help="Upload a local PDF file (max 5MB)"
    )
    
    if uploaded_file and st.button("📄 Add PDF File"):
        # Check file size (5MB limit)
        if uploaded_file.size > 5 * 1024 * 1024:
            st.error("File too large (max 5MB)")
        elif uploaded_file.name not in [f.split('/')[-1] for f in st.session_state.pdf_files]:
            try:
                file_path = f"tmp/{uploaded_file.name}"
                with open(file_path, "wb") as f:
                    f.write(uploaded_file.getbuffer())
                st.session_state.pdf_files.append(file_path)
                # Mark knowledge base for update
                st.session_state.kb_updated = True
                st.success(f"✅ Added: {uploaded_file.name}")
                st.rerun()
            except Exception as e:
                st.error(f"Upload failed: {str(e)}")
        else:
            st.warning("File already added")

    # Display current sources
    if st.session_state.urls or st.session_state.pdf_files:
        st.subheader("📚 Current Knowledge Sources")
        idx = 1
        for url in st.session_state.urls:
            st.markdown(f"{idx}. 🌐 {url}")
            idx += 1
        for pdf_path in st.session_state.pdf_files:
            st.markdown(f"{idx}. 📄 {pdf_path.split('/')[-1]}")
            idx += 1
        
        st.divider()
        if st.button("🔄 Create Vectorization", type="secondary"):
            with st.spinner("Creating embeddings..."):
                try:
                    kb = load_knowledge_base(st.session_state.urls, st.session_state.pdf_files)
                    if kb:
                        st.session_state.kb_updated = True
                        st.success("✅ Vectorization completed!")
                        st.rerun()
                    else:
                        st.error("Failed to create vectorization")
                except Exception as e:
                    st.error(f"Vectorization failed: {e}")
        
        # Check vector status
        if st.button("🔍 Check Vectors"):
            try:
                db = lancedb.connect("lance_db")
                tables = db.table_names()
                if tables:
                    st.success(f"✅ Found {len(tables)} table(s): {tables}")
                    for table_name in tables:
                        table = db.open_table(table_name)
                        count = len(table.to_pandas())
                        st.info(f"Table '{table_name}': {count} vectors")
                else:
                    st.warning("⚠️ No vector tables found")
            except Exception as e:
                st.error(f"Vector check failed: {e}")
        
        # MLflow UI Access
        st.divider()
        st.subheader("📊 MLflow Tracking")
        
        # MLflow logging status
        enable_logging = st.checkbox("Enable MLflow Logging", value=True)
        st.session_state.mlflow_enabled = enable_logging
        
        if enable_logging:
            st.success("✅ Every prompt will be logged with accuracy scores")
        else:
            st.warning("⚠️ MLflow logging disabled")
        
        if st.button("🚀 Open MLflow UI"):
            st.info("Run this command in terminal: `mlflow ui --host 127.0.0.1 --port 5000`")
            st.info("Then visit: http://127.0.0.1:5000")
        
        # LanceDB Web Viewer
        st.divider()
        st.subheader("🗄️ LanceDB Viewer")
        
        if st.button("📊 View Database Tables"):
            try:
                db = lancedb.connect("lance_db")
                tables = db.table_names()
                
                if tables:
                    for table_name in tables:
                        st.write(f"**Table: {table_name}**")
                        table = db.open_table(table_name)
                        df = table.to_pandas()
                        
                        # Show table info
                        st.write(f"Rows: {len(df)}, Columns: {len(df.columns)}")
                        
                        # Show sample data (first 3 rows)
                        if len(df) > 0:
                            sample_df = df[['content', 'source']].head(3)
                            st.dataframe(sample_df)
                        
                        st.divider()
                else:
                    st.warning("No tables found")
            except Exception as e:
                st.error(f"Database access failed: {e}")
        
        if st.button("🔍 Query Database"):
            query_text = st.text_input("SQL-like query (experimental):", placeholder="SELECT * FROM docs LIMIT 5")
            if query_text:
                try:
                    db = lancedb.connect("lance_db")
                    # Basic query support
                    if "docs" in db.table_names():
                        table = db.open_table("docs")
                        df = table.to_pandas()
                        
                        if "LIMIT" in query_text.upper():
                            limit = int(query_text.split("LIMIT")[-1].strip())
                            result_df = df.head(limit)
                        else:
                            result_df = df.head(10)
                        
                        st.dataframe(result_df[['content', 'source']])
                    else:
                        st.warning("No 'docs' table found")
                except Exception as e:
                    st.error(f"Query failed: {e}")
        
        # Direct vector search
        search_query = st.text_input("Direct Vector Search:", placeholder="Enter search query")
        if st.button("🔎 Search Vectors") and search_query:
            try:
                import ollama
                db = lancedb.connect("lance_db")
                table = db.open_table("docs")
                
                # Get query embedding
                response = ollama.embeddings(model="embeddinggemma:latest", prompt=search_query)
                query_embedding = response["embedding"]
                
                # Search vectors
                results = table.search(query_embedding).limit(3).to_pandas()
                
                st.subheader("Search Results:")
                for i, row in results.iterrows():
                    st.write(f"**Result {i+1}:**")
                    st.write(f"Source: {row['source']}")
                    st.write(f"Content: {row['content'][:300]}...")
                    st.divider()
                    
            except Exception as e:
                st.error(f"Search failed: {e}")

# Main title and description
st.title("🔥 Agentic RAG with EmbeddingGemma (100% local)")
st.markdown(
    """
This app demonstrates an agentic RAG system using local models via [Ollama](https://ollama.com/):

- **EmbeddingGemma** for creating vector embeddings
- **LanceDB** as the local vector database
- **Web-based LanceDB viewer** in the sidebar

Add PDF URLs or upload local PDF files in the sidebar to start and ask questions about the content.
    """
)

# LanceDB Web Dashboard (main area)
with st.expander("🗄️ LanceDB Database Dashboard", expanded=False):
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("📈 Database Stats"):
            try:
                db = lancedb.connect("lance_db")
                tables = db.table_names()
                
                st.metric("Total Tables", len(tables))
                
                if tables:
                    for table_name in tables:
                        table = db.open_table(table_name)
                        df = table.to_pandas()
                        st.metric(f"Table '{table_name}' Rows", len(df))
                        
                        # Show vector dimensions
                        if 'vector' in df.columns and len(df) > 0:
                            vector_dim = len(df['vector'].iloc[0]) if df['vector'].iloc[0] is not None else 0
                            st.metric(f"Vector Dimensions", vector_dim)
            except Exception as e:
                st.error(f"Stats failed: {e}")
    
    with col2:
        if st.button("🔍 Browse Data"):
            try:
                db = lancedb.connect("lance_db")
                if "docs" in db.table_names():
                    table = db.open_table("docs")
                    df = table.to_pandas()
                    
                    # Show browseable data
                    st.write("**Recent Documents:**")
                    display_df = df[['content', 'source']].head(5)
                    for idx, row in display_df.iterrows():
                        with st.container():
                            st.write(f"**Source:** {row['source']}")
                            st.write(f"**Content:** {row['content'][:200]}...")
                            st.divider()
                else:
                    st.warning("No data to browse")
            except Exception as e:
                st.error(f"Browse failed: {e}")
# Database connection status
if 'lance_table' in st.session_state:
    st.success("✅ LanceDB Connected - Ready for queries")
else:
    st.info("ℹ️ Upload a PDF to initialize LanceDB")
                
query = st.text_input("Enter your question:")

# Simple answer generation
if st.button("🚀 Get Answer", type="primary"):
    if not query:
        st.error("Please enter a question")
    else:
        # Check if vectors exist
        has_vectors = False
        try:
            db = lancedb.connect("lance_db")
            if "docs" in db.table_names():
                has_vectors = True
        except:
            pass
            
        if not has_vectors and not (st.session_state.urls or st.session_state.pdf_files):
            st.warning("No knowledge sources loaded. Add PDFs to get context-aware answers.")
        elif st.session_state.pdf_files and not has_vectors:
            st.warning("PDFs uploaded but vectors not created. Click 'Create Vectorization' first.")
        
        st.markdown("### 💡 Answer")
        
        with st.spinner("🔍 Searching knowledge and generating answer..."):
            try:
                response = ""
                resp_container = st.empty()
                gen = agent.run(query, stream=True)
                for resp_chunk in gen:
                    if resp_chunk.content is not None:
                        response += resp_chunk.content
                        resp_container.markdown(response)
                
                # Evaluate response quality and log to MLflow
                if response:
                    metrics = evaluate_response_quality(query, response)
                    log_evaluation_metrics(query, response, metrics)
                    
                    # Display comprehensive accuracy metrics
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("Content Accuracy", f"{metrics['content_accuracy']:.2f}")
                    with col2:
                        st.metric("Word Count", metrics['response_length'])
                    with col3:
                        st.metric("Relevance", f"{metrics['relevance_score']:.2f}")
                    with col4:
                        st.metric("Completeness", f"{metrics['completeness']:.2f}")
                        
            except Exception as e:
                st.error(f"Error: {e}")

with st.expander("📖 How This Works"):
    st.markdown(
        """
**This app uses the Phi framework to create an intelligent Q&A system:**

1. **Knowledge Loading**: PDF URLs and local files are processed and stored in LanceDB vector database
2. **EmbeddingGemma as Embedder**: EmbeddingGemma generates local embeddings for semantic search
3. **Llama 3.2**: The Llama 3.2 model generates answers based on retrieved context

**Key Components:**
- `EmbeddingGemma` as the embedder
- `LanceDB` as the vector database
- `PDFUrlKnowledgeBase`: Manages document loading from PDF URLs
- `OllamaEmbedder`: Uses EmbeddingGemma for embeddings
- `Phi Agent`: Orchestrates everything to answer questions
        """
    )
